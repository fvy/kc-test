create
    definer = homestead@`%` function getuserpath(cat_id int) returns text
BEGIN
    DECLARE res TEXT;
    CALL getuserpath(cat_id, res);
    RETURN res;
END;

